Project 1
TTT AI BY LENNY BROWN

To Run, just type "run test1.py"
"I didn't collaborate and all work is my own"

Notes:
The board doesn't switch when full on 9 board.
The human is always 'O' and can't go first
